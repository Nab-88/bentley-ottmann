utilisation: ./bo.py nom_du_test1 nom_du_test2
-> exemple: ./bo.py tests/simple.bo

Le code principal se situe dans le fichier bo.py.
Ce code utilise les modules disponibles dans le dossier geo.
Les tests sont dans le dossier tests.
Le script lancer_tous_les_tests.sh permet de lancer le programme pour tous les tests du dossier 'tests'. (l'ordre des tests a ete choisi arbitrairement)

Le rapport Rapport_TP_Algo.pdf s'appuie sur les données de annexes.pdf

BERNARD Nicolas & DONG Stéphane TD G3
