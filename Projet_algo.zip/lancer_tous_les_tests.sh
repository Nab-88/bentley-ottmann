#!/bin/bash

./bo.py tests/simple.bo tests/simple_three.bo tests/flat_simple.bo tests/fin.bo tests/random_100.bo tests/random_200.bo tests/triangle_0.8.bo tests/triangle_b_1.0.bo tests/triangle_h_0.5.bo tests/triangle_0.1.bo tests/triangle_b_0.5.bo tests/triangle_h_0.1.bo tests/triangle_h_1.0.bo tests/carnifex_h_0.5.bo

